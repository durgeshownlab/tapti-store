-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 09, 2022 at 08:40 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `glory`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `descrip` varchar(255) NOT NULL,
  `keyword` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `title`, `descrip`, `keyword`) VALUES
(1, 'Mens T-shirts', 'mens-tshirts', '', '', ''),
(2, 'Mens Trackpants', 'mens-trackpants', '', '', ''),
(3, 'Mens Polo Tshirts', 'mens-polo-tshirts', '', '', ''),
(4, 'Mens Home Wears', 'mens-home-wears', '', '', ''),
(5, 'Boys Homewears', 'boys-homewears', '', '', ''),
(6, 'Boys Sports Tshirts', 'boys-sports-tshirts', '', '', ''),
(7, 'Mens Sleeveless Tshirts', 'mens-sleeveless-tshirts', '', '', ''),
(8, 'Mens Sports Tshirts', 'mens-sports-tshirts', '', '', ''),
(9, 'Sports Tshirts Full Sleeve', 'sports-tshirts-full-sleeve', '', '', ''),
(10, 'Mens Shorts', 'men-shorts', '', '', ''),
(11, 'Mens Sports Shorts', 'mens-sports-shorts', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `cat_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `feature` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `product_img` varchar(255) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `season` varchar(255) NOT NULL,
  `size` varchar(255) NOT NULL,
  `pattern` varchar(255) NOT NULL,
  `origin` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `cat_id`, `name`, `slug`, `feature`, `gender`, `product_img`, `brand_name`, `color`, `type`, `season`, `size`, `pattern`, `origin`) VALUES
(1, '3', 'Mens Polo Tshirts 227a', 'mens-polo-tshirts-227a', 'Anti-Wrinkle, Comfortable, Easily Washable', 'Mens', 'img/products/mens-polo-tshirts/polo-tshirts-227a.JPG', '', 'Multicolor', 'Polo T-shirts', 'Summer', 'S,M,L,XL,XXL,XXXL', 'Plain', 'India'),
(2, '3', 'Polo Tshirts 233b', 'polo-tshirts-233b', 'Anti-Wrinkle, Comfortable, Easily Washable', 'Mens', 'img/products/mens-polo-tshirts/polo-tshirts-233b.JPG', '', 'Multicolor', 'Polo T-shirts', 'Summer', 'S,M,L,XL,XXL,XXXL', 'Plain', 'India'),
(3, '3', 'Polo Tshirts 227D', 'polo-tshirts-227D', 'Anti-Wrinkle, Comfortable, Easily Washable', 'Mens', 'img/products/mens-polo-tshirts/polo-tshirts-227D.JPG', '', 'Multicolor', 'Polo T-shirts', 'Summer', 'S,M,L,XL,XXL,XXXL', 'Plain', 'India'),
(4, '1', 'Mens Tshirts 1104pb', 'mens-tshirts-1104-pb', 'Durable, Easily Washable, Eco Friendy, Skin Friendly, Soft', 'Mens', 'img/products/mens-tshirts/tshirts-1104-pb.jpg', '', 'Multicolor', 'Designer Printed T-shirts', 'Summer', 'L, M, S, XL, XXL', 'Printed', 'India'),
(5, '1', 'Mens Tshirts 1092c', 'mens-tshirts-1092c', 'Comfortable, Easily Washable, Fad Less Color', 'Mens', 'img/products/mens-tshirts/tshirts-1092c.jpg', '', 'Multicolor', 'Designer Mens Tshirt', 'Summer', 'L, M, S, XL, XXL', 'Printed', 'India'),
(6, '1', 'Mens Tshirts 3118A', 'mens-tshirts-3118A', 'Durable, Easily Washable, Eco Friendy, Skin Friendly, Soft', 'Mens', 'img/products/mens-tshirts/tshirts-3118A.jpg', '', 'Multicolor', 'Printed Mens Tshirt', 'Summer', 'L, M, S, XL, XXL', 'Printed', 'India'),
(7, '2', 'Mens Trackpants 7055A', 'mens-trackpants-7055A', 'Easily Washable, Comfortable', 'Mens', 'img/products/mens-trackpants/trackpants-7055A.jpg', '', 'Multicolor', 'Track Pants', 'Summer, Winter', 'L, M, S, XL, XXL, XXXL', 'Plain, Printed', 'India'),
(8, '2', 'Mens Trackpants 7053A', 'mens-trackpants-7053A', 'Anti-Wrinkle, Comfortable, Easily Washable', 'Mens', 'img/products/mens-trackpants/trackpants-7053A.JPG', '', 'Multicolor', 'Track Pants', 'Summer, Winter', 'L, M, S, XL, XXL, XXXL', 'Plain, Printed', 'India'),
(9, '2', 'Mens Trackpants 7027B', 'mens-trackpants-7027-B', 'Easily Washable, Comfortable', 'Mens', 'img/products/mens-trackpants/trackpants-7027-B.jpg', '', 'Multicolor', 'Track Pants', 'Summer, Winter', 'L, M, S, XL, XXL, XXXL', 'Plain, Printed', 'India'),
(10, '4', 'Mens Homewear Long 808B', 'mens-homewear-long-808-B', 'Anti-Shrink, Anti-Wrinkle, Breathable', 'Mens', 'img/products/mens-home-wears/homewear-long/homewear-long-808-B.JPG', '', 'Multicolor', 'Track Pant & Tshirt', 'Summer', 'L, M, XXL, XXXL', 'Plain,Printed', 'India'),
(11, '4', 'Mens Homewear Long 809A', 'mens-homewear-long-809-A', 'Casual Wear,Anti-Shrink,Breathable', 'Mens', 'img/products/mens-home-wears/homewear-long/homewear-long-809-A.JPG', '', 'Multicolor', 'Track Pant & Tshirt', 'Summer', 'L, M, XXL, XXXL', 'Plain,Printed', 'India'),
(12, '4', 'Mens Homewear Long 813b', 'mens-homewear-long-813-b', 'Anti-Shrink, Anti-Wrinkle, Breathable', 'Mens', 'img/products/mens-home-wears/homewear-long/homewear-long-813-b.JPG', '', 'Multicolor', 'Track Pant & Tshirt', 'Summer', 'L, M, XXL, XXXL', 'Plain,Printed', 'India'),
(13, '4', 'Homewear Short 703a', 'homewear-short-703a', 'Easy Washable, Quick Dry', 'Mens', 'img/products/mens-home-wears/homewear-short/homewear-short-703a.JPG', '', 'Multicolor', 'Mens homewear', 'Summer, Winter', 'S to XL', 'Plain,Printed', 'India'),
(14, '4', 'Mens Homewear Short 708b', 'homewear-short-708b', 'Comfortable, Easily Washable', 'Mens', 'img/products/mens-home-wears/homewear-short/homewear-short-708b.JPG', '', 'Multicolor', 'Fancy shorts', 'Spring, Summer', 'Small, Medium, Large, XL', 'Plain,Printed', 'India'),
(15, '4', 'Mens Homewear Short 717A', 'mens-homewear-short-717-A', 'Easy Washable, Quick Dry', 'Mens', 'img/products/mens-home-wears/homewear-short/homewear-short-717-a.JPG', '', 'Multicolor', 'Mens short', 'Spring, Summer', 'Small, Medium, Large, XL', 'Plain,Printed', 'India'),
(16, '7', 'Mens Sleeveless Tshirts 4042A', 'mens-sleeveless-tshirts-4042A', 'Comfortable, Impeccable Finish', 'Mens', 'img/products/sleeveless-tshirts/sleeveless-tshirts-4042a.jpg', '', 'Multicolor', 'Sleeveless', 'Summer', 'L, M, S, XL, XXL', 'Plain,Printed', 'India'),
(17, '7', 'Mens Sleeveless Tshirts 4039B', 'mens-sleeveless-tshirts-4039b', 'Comfortable, Anti-Wrinkle', 'Mens', 'img/products/sleeveless-tshirts/sleeveless-tshirts-4039b.jpg', '', 'Multicolor', 'Sleeveless', 'Summer', 'L, M, S, XL, XXL', 'Plain,Printed', 'India'),
(18, '7', 'Mens Sleeveless Tshirts 4055A', 'mens-sleeveless-tshirts-4055a', 'Comfortable, Impeccable Finish', 'Mens', 'img/products/sleeveless-tshirts/sleeveless-tshirts-4055a.jpg', '', 'Multicolor', 'Sleeveless', 'Summer', 'L, M, S, XL, XXL', 'Plain,Printed', 'India'),
(19, '6', 'Boys Sports Tshirts 9006A', 'boys-sports-tshirts-9006a', 'Anti-shrink,Anti-wrinkle,Breathable,Comfortable,Easily Washable ', 'Boys', 'img/products/boys-sports-tshirts/Sports-tshirts-9006a.jpg', '', 'Multicolor', 'Boys Sports T-Shirts,', 'Summer', 'L, M, S, XL, XXL', 'Plain,Printed', 'India'),
(20, '6', 'Boys Sports Tshirts 9006C', 'boys-sports-tshirts-9006c', 'Comfortable, Easily Washable', 'Boys', 'img/products/boys-sports-tshirts/Sports-tshirts-9006c.jpg', '', 'Multicolor', 'Boys Sports T-Shirts,', 'Summer', 'L, M, S, XL, XXL', 'Plain,Printed', 'India'),
(21, '6', 'Boys Sports Tshirts 9006D', 'boys-sports-tshirts-9006d', 'Anti-Wrinkle, Comfortable, Easily Washable, Skin Friendly', 'Boys', 'img/products/boys-sports-tshirts/Sports-tshirts-9006d.jpg', '', 'Multicolor', 'Boys Sports T-Shirts,', 'Summer', 'L, M, S, XL, XXL', 'Plain,Printed', 'India'),
(22, '5', 'Boys Homewears 601-A', 'Boys-homewears-601-A', 'Anti-Wrinkle, Comfortable, Easily Washable', 'Boys', 'img/products/boys-homewears/Boys-homewears-601-A.jpg', '', 'Multicolor', 'Homewears Cloths', 'Summer', 'L, M, S, XL, XXL', 'Plain,Printed', 'India'),
(23, '5', 'Boys Homewears 603-A', 'Boys-homewears-603-A', 'Comfortable, Easily Washable', 'Boys', 'img/products/boys-homewears/Boys-homewears-603-A.jpg', '', 'Multicolor', 'Homewears Cloths', 'Summer', 'L, M, S, XL, XXL', 'Plain,Printed', 'India'),
(24, '5', 'Boys Hhomewears 611-A', 'Boys-homewears-611-A', 'Easy Washable, Quick Dry', 'Boys', 'img/products/boys-homewears/Boys-homewears-611-A.jpg', '', 'Multicolor', 'Homewears Cloths', 'Summer', 'L, M, S, XL, XXL', 'Plain,Printed', 'India'),
(25, '10', 'Mens Shorts 6035A', 'mens-shorts-6035a', 'Anti-Wrinkle, Comfortable', 'Mens', 'img/products/mens-shorts/mens-shorts-6035a.JPG', '', 'Multicolor', 'Fancy Mens Cotton Shorts', 'Summer', 'All sizes are available', 'Plain,Printed', 'India'),
(26, '10', 'Mens Shorts 6038B1', 'mens-shorts-6038b1', 'Anti-Wrinkle, Comfortable, Easily Washable', 'Mens', 'img/products/mens-shorts/mens-shorts-6038b1.JPG', '', 'Multicolor', 'Fancy Mens Cotton Shorts', 'Summer', 'All sizes are available', 'Plain,Printed', 'India'),
(27, '10', 'Mens Shorts 6041-A', 'mens-shorts-6041-a.JPG', 'Comfortable, Easily Washable', 'Mens', 'img/products/mens-shorts/mens-shorts-6041-a.JPG', '', 'Multicolor', 'Fancy Mens Cotton Shorts', 'Summer', 'All sizes are available', 'Plain,Printed', 'India'),
(28, '8', 'Mens Sports Tshirts 9005A', 'mens-sports-tshirts-9005a', 'Easily Washable, Comfortable', 'Mens', 'img/products/sports-tshirts/mens-sports-tshirts-9005a.JPG', '', 'Multicolor', 'Sports Tshirt', 'Summer', 'L, M, S, XL, XXL', 'Plain,Printed', 'India'),
(29, '8', 'Mens Sports Tshirts 9006c', 'mens-sports-tshirts-9006c', 'Easy Washable, Quick Dry', 'Mens', 'img/products/sports-tshirts/mens-sports-tshirts-9006c.jpg', '', 'Multicolor', 'Sports Tshirt', 'Summer', 'L, M, S, XL, XXL', 'Plain,Printed', 'India'),
(30, '8', 'Mens Sports Tshirts 9007B', 'mens-sports-tshirts-9007b', 'Anti-Wrinkle, Comfortable,Quick Dry', 'Mens', 'img/products/sports-tshirts/mens-sports-tshirts-9007b.JPG', '', 'Multicolor', 'Sports Tshirts', 'Summer', 'L, M, S, XL, XXL, XXXL', 'Plain,Printed', 'India'),
(31, '9', 'Mens Tshirts Full Sleeve 9008D', 'mens-tshirts-full-sleeve-9008-D', 'Anti-Wrinkle, Quick Dry, Shrink Resistance', 'Mens', 'img/products/sports-tshirts-full-sleeve/mens-tshirts-full-sleeve-9008-D.JPG', '', 'Multicolor', 'Full Sleeve Tshirt', 'Summer', ' S, M, L, XL, XXL, XXXL', 'Plain,Printed', 'India'),
(32, '9', 'Mens Tshirts Full Sleeve 9008-E', 'mens-tshirts-full-sleeve-9008-E', 'Easy Washable,Quick Dry, Comfortable', 'Mens', 'img/products/sports-tshirts-full-sleeve/mens-tshirts-full-sleeve-9008-E.JPG', '', 'Multicolor', 'Full Sleeve Tshirt', 'Summer', ' S, M, L, XL, XXL, XXXL', 'Plain,Printed', 'India'),
(33, '9', 'Mens Tshirts Full Sleeve 9008-f', 'mens-tshirts-full-sleeve-9008-f', 'Easy Washable,Quick Dry, Comfortable', 'Mens', 'img/products/sports-tshirts-full-sleeve/mens-tshirts-full-sleeve-9008-f.JPG', '', 'Multicolor', 'Full Sleeve Tshirt', 'Summer', ' S, M, L, XL, XXL, XXXL', 'Plain,Printed', 'India'),
(34, '11', 'Mens Sports Shorts 6039A', 'mens-sports-shorts-6039a', 'Quick Dry, Comfortable, Easy Washable,Shrink Resistance', 'Mens', 'img/products/sports-shorts-mens/mens-sports-shorts-6039a.JPG', '', 'All colors are available', 'Sports Shorts', 'Spring, Summer, Winter', 'L, M, S, XL, XXL', 'Plain,Printed', 'India'),
(35, '11', 'Mens Sports Shorts 6039B', 'mens-sports-shorts-6039b', 'Quick Dry, Shrink Resistance,Comfortable, Easy Washable', 'Mens', 'img/products/sports-shorts-mens/mens-sports-shorts-6039b.JPG', '', 'All colors are available', 'Sports Shorts', 'Spring, Summer, Winter', 'L, M, S, XL, XXL', 'Plain,Printed', 'India'),
(36, '11', 'Mens Sports Shorts 6039C', 'mens-sports-shorts-6039-c', 'Comfortable, Easy Washable,Quick Dry, Shrink Resistance', 'Mens', 'img/products/sports-shorts-mens/mens-sports-shorts-6039b.JPG', '', 'All colors are available', 'Sports Shorts', 'Spring, Summer, Winter', 'L, M, S, XL, XXL', 'Plain,Printed', 'India');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
